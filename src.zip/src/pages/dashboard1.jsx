import React, { useState } from 'react';
import {
  Box,
  CssBaseline,
  Toolbar,
  List,
  ListItem,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  IconButton,
  Typography,
  Card,
  CardContent,
  Grid,
  Paper,
} from '@mui/material';
import {
  Menu as MenuIcon,
  ChevronLeft as ChevronLeftIcon,
  ChevronRight as ChevronRightIcon,
  Dashboard as DashboardIcon,
  Campaign as AnnouncementIcon,
  Description as DocumentIcon,
  CorporateFare as OrganizerIcon,
  Group as UserIcon,
  Backup as BackupIcon,
  Notifications as NotificationsIcon,
  AccountCircle as AccountCircleIcon,
} from '@mui/icons-material';
import { styled, useTheme } from '@mui/material/styles';
import MuiDrawer from '@mui/material/Drawer';
import MuiAppBar from '@mui/material/AppBar';
import { useNavigate } from 'react-router-dom'; // Added this import
import forbesLogo from '../images/forbes-logo.png';
import citeLogo from '../images/fyi-logo.png'; // Adjust the import path accordingly

const drawerWidth = 240;

const openedMixin = (theme) => ({
  width: drawerWidth,
  transition: theme.transitions.create('width', {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.enteringScreen,
  }),
  overflowX: 'hidden',
  backgroundColor: '#EBF6F0',
});

const closedMixin = (theme) => ({
  transition: theme.transitions.create('width', {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.leavingScreen,
  }),
  overflowX: 'hidden',
  width: `calc(${theme.spacing(7)} + 1px)`,
  [theme.breakpoints.up('sm')]: {
    width: `calc(${theme.spacing(6)} + 1px)`,
  },
  backgroundColor: '#EBF6F0',
});

const DrawerHeader = styled('div')(({ theme }) => ({
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'flex-end',
  padding: theme.spacing(0, 1),
  ...theme.mixins.toolbar,
}));

const AppBar = styled(MuiAppBar, {
  shouldForwardProp: (prop) => prop !== 'open',
})(({ theme }) => ({
  zIndex: theme.zIndex.drawer + 1,
  backgroundColor: '#EBF6F0',
}));

const Drawer = styled(MuiDrawer, { shouldForwardProp: (prop) => prop !== 'open' })(
  ({ theme, open }) => ({
    width: drawerWidth,
    flexShrink: 0,
    whiteSpace: 'nowrap',
    boxSizing: 'border-box',
    ...(open && {
      ...openedMixin(theme),
      '& .MuiDrawer-paper': openedMixin(theme),
    }),
    ...(!open && {
      ...closedMixin(theme),
      '& .MuiDrawer-paper': closedMixin(theme),
    }),
  })
);

export default function MiniDrawer() {
  const theme = useTheme();
  const [open, setOpen] = useState(false);
  const [activeTab, setActiveTab] = useState('Dashboard');
  const navigate = useNavigate(); // Initialize useNavigate

  const handleDrawerOpen = () => setOpen(true);
  const handleDrawerClose = () => setOpen(false);
  const handleTabClick = (tab) => setActiveTab(tab);
  const handleLogout = () => navigate('/'); // Redirect to login page
  const handleProfileMenuOpen = () => {
    console.log('Profile menu opened'); // Placeholder for profile menu open logic
  };

  const menuItems = [
    { text: 'Dashboard', icon: <DashboardIcon sx={{ fontSize: 30 }} />, onClick: () => handleTabClick('Dashboard') },
    { text: 'Announcement', icon: <AnnouncementIcon sx={{ fontSize: 30 }} />, onClick: () => handleTabClick('Announcement') },
    { text: 'Document Approval', icon: <DocumentIcon sx={{ fontSize: 30 }} />, onClick: () => handleTabClick('Document Approval') },
    { text: 'Organization', icon: <OrganizerIcon sx={{ fontSize: 30 }} />, onClick: () => handleTabClick('Organization') },
    { text: 'Users', icon: <UserIcon sx={{ fontSize: 30 }} />, onClick: () => handleTabClick('Users') },
    { text: 'Backup & Restore', icon: <BackupIcon sx={{ fontSize: 30 }} />, onClick: () => handleTabClick('Backup & Restore') },
  ];

  const eventCards = [
    { text: 'Forbes Young Innovators', img: citeLogo },
    { text: 'Forbes Young Innovators', img: citeLogo },
    { text: 'Forbes Young Innovators', img: citeLogo },
    { text: 'Forbes Young Innovators', img: citeLogo },
    { text: 'Forbes Young Innovators', img: citeLogo },
    { text: 'Forbes Young Innovators', img: citeLogo },
  ];

  return (
    <Box sx={{ display: 'flex' }}>
      <CssBaseline />
      <AppBar position="fixed" open={open}>
        <Toolbar>
        <IconButton onClick={open ? handleDrawerClose : handleDrawerOpen} edge="start" sx={{ marginRight: 2 }}>
            <MenuIcon />
          </IconButton>
          
          <Typography variant="h6" noWrap component="div" sx={{ flexGrow: 1 }}>
            Dashboard
          </Typography>
          <IconButton>
            <NotificationsIcon sx={{ fontSize: 30, color: 'black' }} />
          </IconButton>
          <IconButton onClick={handleProfileMenuOpen}>
            <AccountCircleIcon sx={{ fontSize: 30, color: 'black' }} />
          </IconButton>
        </Toolbar>
      </AppBar>
      <Drawer variant="permanent" open={open}>
        <DrawerHeader>
          <img src={forbesLogo} className="logo" alt="Forbes logo" style={{ marginLeft: 'auto', marginRight: 'auto' }} />
          <IconButton onClick={handleDrawerClose}>
            {theme.direction === 'rtl' ? <ChevronRightIcon /> : <ChevronLeftIcon />}
          </IconButton>
        </DrawerHeader>
        <List>
          {menuItems.map((item, index) => (
            <ListItem key={item.text} disablePadding sx={{ display: 'block' }}>
              <ListItemButton
                onClick={item.onClick}
                sx={{
                  minHeight: 48,
                  justifyContent: open ? 'initial' : 'center',
                  px: 2.5,
                  borderRadius: 2,
                  backgroundColor: activeTab === item.text ? 'white' : 'inherit',
                  color: activeTab === item.text ? 'blue' : 'inherit',
                  boxShadow: activeTab === item.text ? 5 : 0,
                  '&:hover': {
                    backgroundColor: 'rgba(0, 0, 0, 0.04)',
                  },
                }}
              >
                <ListItemIcon
                  sx={{
                    minWidth: 0,
                    mr: open ? 3 : 'auto',
                    justifyContent: 'center',
                    color: activeTab === item.text ? '#1A8BE1' : 'inherit',
                  }}
                >
                  {item.icon}
                </ListItemIcon>
                <ListItemText primary={item.text} sx={{ opacity: open ? 1 : 0 }} />
                {index === 0 && (
                  <IconButton
                    onClick={open ? handleDrawerClose : handleDrawerOpen}
                    sx={{
                      color: 'black',
                      marginLeft: 'auto',
                    }}
                  >
                    <MenuIcon />
                  </IconButton>
                )}
              </ListItemButton>
            </ListItem>
          ))}
        </List>
      </Drawer>
      <Box
        sx={{
          flexGrow: 1,
          backgroundColor: '#EBF6F0',
          padding: 3,
          marginLeft: '10px',
          marginTop: '75px',
          display: 'flex',
          flexDirection: 'column',
          borderTopLeftRadius: '10px',
          boxShadow: 4,
        }}
      >
        {activeTab === 'Dashboard' && (
          <>
            <Grid container spacing={2} sx={{ marginTop: 2 }}>
              <Grid item xs={9}>
                <Typography variant="h4" gutterBottom>
                  Good Day Admin!
                </Typography>
                <Typography variant="subtitle1" gutterBottom>
                  Tuesday, June 04, 2024
                </Typography>
                <Grid container spacing={3} sx={{ marginTop: 1 }}>
                  <Grid item xs={5}>
                    <Card sx={{ backgroundColor: '#54B173', borderRadius: '10px' }}>
                      <CardContent>
                        <Typography variant="h5" component="div">
                          Announcements
                        </Typography>
                        <Typography variant="h4" component="div" sx={{ color: 'white' }}>
                          2
                        </Typography>
                      </CardContent>
                    </Card>
                  </Grid>
                </Grid>
                <Typography variant="h6" gutterBottom sx={{ marginTop: 3 }}>
                  Event Cards
                </Typography>
                <Grid container spacing={2}>
                  {eventCards.map((card, index) => (
                    <Grid item xs={4} md={3} key={index}>
                      <Card
                        sx={{
                          backgroundColor: '#40C4FF',
                          borderRadius: '10px',
                          display: 'flex',
                          alignItems: 'center',
                          padding: 2,
                          height: '100%',
                          boxSizing: 'border-box',
                        }}
                      >
                        <img
                          src={card.img}
                          alt="Event logo"
                          style={{ width: 40, height: 40, marginRight: 10, borderRadius: 20 }}
                        />
                        <Typography variant="h6" component="div" sx={{ color: 'white' }}>
                          {card.text}
                        </Typography>
                      </Card>
                    </Grid>
                  ))}
                </Grid>
              </Grid>
              <Grid item xs={3}>
                <Paper elevation={0} sx={{ padding: 2, backgroundColor: '#6F9675', borderRadius: '10px' }}>
                  <Typography variant="h6" component="div">
                    Upcoming Events
                  </Typography>
                  <List sx={{ margin: '10px', borderRadius: '5px' }}>
                    <ListItem sx={{ backgroundColor: 'white', marginBottom: '5px', borderRadius: '5px' }}>
                      <ListItemText primary="June 16" secondary="Meeting with Research Group" />
                    </ListItem>
                    <ListItem sx={{ backgroundColor: 'white', marginBottom: '5px', borderRadius: '5px' }}>
                      <ListItemText primary="June 17" secondary="Team Building Activities" />
                    </ListItem>
                    <ListItem sx={{ backgroundColor: 'white', marginBottom: '5px', borderRadius: '5px' }}>
                      <ListItemText primary="June 18" secondary="Workshop on Innovation" />
                    </ListItem>
                    <ListItem sx={{ backgroundColor: 'white', marginBottom: '5px', borderRadius: '5px' }}>
                      <ListItemText primary="June 23" secondary="End of Semester Celebration" />
                    </ListItem>
                  </List>
                </Paper>
              </Grid>
            </Grid>
          </>
        )}
      </Box>
    </Box>
  );
}
